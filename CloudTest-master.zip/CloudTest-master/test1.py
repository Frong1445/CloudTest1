print ("Hello Python")
print ("Hello Python")
print ("Hello Python")